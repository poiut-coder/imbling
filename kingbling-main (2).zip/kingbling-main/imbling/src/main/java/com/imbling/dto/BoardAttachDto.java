package com.imbling.dto;

import lombok.Data;

@Data
public class BoardAttachDto {

    private int attachNo;
    private String attachName;
    private String savedAttachName;
    private int boardNo;
}
