package com.imbling.dto;

import lombok.Data;

@Data
public class PropertyDto {

	private int propertyNo;
	private String productColor;
	private String productSize;
	private int productEA;
	
}
