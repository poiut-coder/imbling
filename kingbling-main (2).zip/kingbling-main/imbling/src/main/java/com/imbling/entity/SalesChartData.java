package com.imbling.entity;

public interface SalesChartData {
	
	Integer getOrderPrice();

	String getOrderDate();
}
